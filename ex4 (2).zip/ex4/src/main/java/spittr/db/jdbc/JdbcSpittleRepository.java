package spittr.db.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import spittr.db.SpittleRepository;
import spittr.domain.Spittle;
import spittr.domain.Spitter;


@Repository
public class JdbcSpittleRepository implements SpittleRepository {

	private final JdbcTemplate jdbc;

	@Override
	public Page<Spittle> findAll(Pageable pageable) {
		// 1. 计算偏移量（跳过的记录数 = 页码 * 每页条数）
		int offset = pageable.getPageNumber() * pageable.getPageSize();

		// 2. 查询当前页数据（包含已审核和未审核的所有记录）
		String dataSql = "SELECT s.*, sp.id AS spitter_id, sp.username, sp.first_name, sp.last_name, sp.email " +
				"FROM spittle s JOIN Spitter sp ON s.spitter = sp.id " +
				"ORDER BY s.postedTime DESC LIMIT ? OFFSET ?";
		List<Spittle> spittles = jdbc.query(
				dataSql,
				new SpittleRowMapper(), // 已有的行映射器
				pageable.getPageSize(),
				offset
		);

		// 3. 查询总记录数
		String countSql = "SELECT COUNT(*) FROM spittle";
		long total = jdbc.queryForObject(countSql, Long.class);

		// 4. 封装为 Page 对象返回
		return new PageImpl<>(spittles, pageable, total);
	}

	@Autowired
	public JdbcSpittleRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public long count() {
		return jdbc.queryForLong("SELECT COUNT(*) FROM spittle");
	}

	@Override
	public List<Spittle> findRecent() {
		return findRecent(10);
	}

	@Override
	public List<Spittle> findRecent(int count) {
		return jdbc.query(
				"SELECT s.*, sp.id AS spitter_id, sp.username, sp.first_name, sp.last_name, sp.email " +
						"FROM spittle s JOIN Spitter sp ON s.spitter = sp.id " +
						"WHERE s.is_checked = TRUE " +
						"ORDER BY s.postedTime DESC LIMIT ?",
				new SpittleRowMapper(),
				count
		);
	}

	@Override
	public Spittle findOne(long id) {
		try {
			return jdbc.queryForObject(
					"SELECT s.*, sp.id AS spitter_id, sp.username, sp.first_name, sp.last_name, sp.email " +
							"FROM spittle s JOIN Spitter sp ON s.spitter = sp.id " +
							"WHERE s.id = ?",
					new SpittleRowMapper(),
					id
			);
		} catch (DataAccessException e) {
			return null;
		}
	}

	@Override
	public Spittle save(Spittle spittle) {
		jdbc.update(
				"INSERT INTO spittle (spitter, message, postedTime, is_checked) " +
						"VALUES (?, ?, ?, FALSE)",
				spittle.getSpitter().getId(),
				spittle.getMessage(),
				spittle.getPostedTime()
		);
		return spittle;
	}

	@Override
	public List<Spittle> findBySpitterId(long spitterId) {
		return jdbc.query(
				"SELECT s.*, sp.id AS spitter_id, sp.username, sp.first_name, sp.last_name, sp.email " +
						"FROM spittle s JOIN Spitter sp ON s.spitter = sp.id " +
						"WHERE s.spitter = ? AND s.is_checked = TRUE " +
						"ORDER BY s.postedTime DESC",
				new SpittleRowMapper(),
				spitterId
		);
	}

	@Override
	public void delete(long id) {
		jdbc.update("DELETE FROM spittle WHERE id = ?", id);
	}

	@Override
	public List<Spittle> findUncheckedSpittles(int offset, int pageSize) {
		return jdbc.query(
				"SELECT s.*, sp.id AS spitter_id, sp.username, sp.first_name, sp.last_name, sp.email " +
						"FROM spittle s JOIN Spitter sp ON s.spitter = sp.id " +
						"WHERE s.is_checked = FALSE " +
						"ORDER BY s.postedTime DESC LIMIT ? OFFSET ?",
				new SpittleRowMapper(),
				pageSize, offset
		);
	}

	@Override
	public long countUncheckedSpittles() {
		return jdbc.queryForLong("SELECT COUNT(*) FROM spittle WHERE spittle.is_checked = FALSE");
	}

	@Override
	public void checkSpittle(long spittleId, long checkerId) {
		jdbc.update(
				"UPDATE spittle " +
						"SET is_checked = TRUE, checker_id = ?, check_time = ? " +
						"WHERE id = ?",
				checkerId, new Date(), spittleId
		);
	}

	// 实现分页查询未审核的方法（适配Page接口）
	@Override
	public Page<Spittle> findByCheckedFalse(Pageable pageable) {
		int offset = pageable.getPageNumber() * pageable.getPageSize();
		List<Spittle> spittles = findUncheckedSpittles(offset, pageable.getPageSize());
		long total = countUncheckedSpittles();
		return new PageImpl<>(spittles, pageable, total);
	}

	// 实现更新审核状态的方法
	@Override
	public void updateCheckedStatus(long id, boolean status) {
		jdbc.update(
				"UPDATE spittle SET is_checked = ? WHERE id = ?",
				status, id
		);
	}

	private static class SpittleRowMapper implements RowMapper<Spittle> {
		@Override
		public Spittle mapRow(ResultSet rs, int rowNum) throws SQLException {
			Spitter spitter = new Spitter(
					rs.getLong("spitter_id"),
					rs.getString("username"),
					null,
					rs.getString("first_name"),
					rs.getString("last_name"),
					rs.getString("email")
			);
			Spittle spittleObj = new Spittle();
			spittleObj.setId(rs.getLong("id"));
			spittleObj.setSpitter(spitter);
			spittleObj.setMessage(rs.getString("message"));
			spittleObj.setPostedTime(rs.getTimestamp("postedTime"));
			spittleObj.setChecked(rs.getBoolean("is_checked"));
			spittleObj.setCheckerId(rs.getLong("checker_id"));
			spittleObj.setCheckTime(rs.getTimestamp("check_time"));
			return spittleObj;
		}
	}
}