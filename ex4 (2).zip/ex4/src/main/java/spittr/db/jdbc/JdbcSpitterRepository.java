package spittr.db.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import spittr.db.SpitterRepository;
import spittr.domain.Spitter;

@Repository
public class JdbcSpitterRepository implements SpitterRepository {

	private JdbcTemplate jdbc;

	@Autowired
	public JdbcSpitterRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	// 实现分页查询方法（解决错误的核心）
	@Override
	public Page<Spitter> findAll(Pageable pageable) {
		// 1. 计算分页参数：跳过的记录数 = 页码 * 每页条数
		int offset = pageable.getPageNumber() * pageable.getPageSize();

		// 2. 查询当前页的数据
		String dataSql = "SELECT id, username, first_name, last_name, email " +
				"FROM Spitter " +
				"ORDER BY id DESC " +
				"LIMIT ? OFFSET ?";
		List<Spitter> spitters = jdbc.query(
				dataSql,
				new SpitterRowMapper(),
				pageable.getPageSize(),  // 每页显示的记录数
				offset                   // 跳过的记录数
		);

		// 3. 查询总记录数（用于计算总页数）
		String countSql = "SELECT COUNT(*) FROM Spitter";
		long total = jdbc.queryForObject(countSql, Long.class);

		// 4. 封装为Page对象返回
		return new PageImpl<>(spitters, pageable, total);
	}

	@Override
	public Spitter save(Spitter spitter) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbc.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_SPITTER, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, spitter.getUserName());
			ps.setString(2, spitter.getPassword());
			ps.setString(3, spitter.getFirstName());
			ps.setString(4, spitter.getLastName());
			ps.setString(5, spitter.getEmail());
			return ps;
		}, keyHolder);
		spitter.setId(keyHolder.getKey().longValue());
		return spitter;
	}

	@Override
	public Spitter findByUserName(String userName) {
		try {
			return jdbc.queryForObject(SELECT_SPITTER + " where username=?",
					new SpitterRowMapper(), userName);
		} catch (DataAccessException e) {
			return null;
		}
	}

	@Override
	public Spitter findByUserNameAndPassword(String userName, String password) {
		try {
			return jdbc.queryForObject(SELECT_SPITTER + " where username=? and password=?",
					new SpitterRowMapper(), userName, password);
		} catch (DataAccessException e) {
			return null;
		}
	}

	@Override
	public long count() {
		return jdbc.queryForObject("select count(id) from Spitter", Long.class);
	}

	@Override
	public Spitter findOne(long id) {
		try {
			return jdbc.queryForObject(SELECT_SPITTER + " where id=?",
					new SpitterRowMapper(), id);
		} catch (DataAccessException e) {
			return null;
		}
	}

	// 注意：这是不分页的查询所有方法，与分页方法区分开
	@Override
	public List<Spitter> findAll() {
		return jdbc.query(SELECT_SPITTER + " order by id", new SpitterRowMapper());
	}

	private static class SpitterRowMapper implements RowMapper<Spitter> {
		public Spitter mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Spitter(
					rs.getLong("id"),
					rs.getString("username"),
					null,  // 密码通常不返回
					rs.getString("first_name"),
					rs.getString("last_name"),
					rs.getString("email")
			);
		}
	}

	private static final String INSERT_SPITTER = "insert into Spitter (username, password, first_name, last_name, email) values (?, ?, ?, ?, ?)";
	private static final String SELECT_SPITTER = "select id, username, first_name, last_name, email from Spitter";
}
