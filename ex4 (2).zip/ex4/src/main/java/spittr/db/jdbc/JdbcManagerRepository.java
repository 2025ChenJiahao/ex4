package spittr.db.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import spittr.db.ManagerRepository;
import spittr.domain.Manager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

@Repository
public class JdbcManagerRepository implements ManagerRepository {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcManagerRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // 结果集映射器（统一转换数据库记录为Manager对象）
    private static final RowMapper<Manager> MANAGER_ROW_MAPPER = new RowMapper<Manager>() {
        @Override
        public Manager mapRow(ResultSet rs, int rowNum) throws SQLException {
            Manager manager = new Manager();
            manager.setId(rs.getLong("id"));
            manager.setUsername(rs.getString("username"));
            manager.setPassword(rs.getString("password"));
            manager.setFullName(rs.getString("full_name"));
            manager.setEmail(rs.getString("email"));
            manager.setPhoneNo(rs.getString("phone_no"));
            manager.setCreateTime(rs.getTimestamp("create_time"));
            manager.setDeleted(rs.getBoolean("is_deleted"));
            return manager;
        }
    };

    @Override
    public Manager findById(Long id) {
        String sql = "SELECT * FROM manager WHERE id = ? AND is_deleted = FALSE";
        try {
            return jdbcTemplate.queryForObject(sql, MANAGER_ROW_MAPPER, id);
        } catch (Exception e) {
            return null; // 未找到或已删除返回null
        }
    }

    @Override
    public Manager findByUserName(String userName) {
        String sql = "SELECT * FROM manager WHERE username = ? AND is_deleted = FALSE";
        try {
            return jdbcTemplate.queryForObject(sql, MANAGER_ROW_MAPPER, userName);
        } catch (Exception e) {
            return null; // 未找到或已删除返回null
        }
    }

    @Override
    public Manager findByUsernameAndPassword(String username, String password) {
        String sql = "SELECT * FROM manager WHERE username = ? AND password = ? AND is_deleted = FALSE";
        try {
            return jdbcTemplate.queryForObject(sql, MANAGER_ROW_MAPPER, username, password);
        } catch (Exception e) {
            return null; // 账号密码错误或已删除返回null
        }
    }

    @Override
    public List<Manager> findAll() {
        String sql = "SELECT * FROM manager WHERE is_deleted = FALSE ORDER BY create_time DESC";
        return jdbcTemplate.query(sql, MANAGER_ROW_MAPPER);
    }

    @Override
    public Page<Manager> findAll(Pageable pageable) {
        int offset = pageable.getPageNumber() * pageable.getPageSize();
        // 查询当前页数据
        String dataSql = "SELECT * FROM manager WHERE is_deleted = FALSE ORDER BY create_time DESC LIMIT ? OFFSET ?";
        List<Manager> managers = jdbcTemplate.query(
                dataSql,
                MANAGER_ROW_MAPPER,
                pageable.getPageSize(),
                offset
        );
        // 查询总记录数
        String countSql = "SELECT COUNT(*) FROM manager WHERE is_deleted = FALSE";
        long total = jdbcTemplate.queryForObject(countSql, Long.class);
        return new PageImpl<>(managers, pageable, total);
    }

    @Override
    public void save(Manager manager) {
        String sql = "INSERT INTO manager (" +
                "username, password, full_name, email, phone_no, create_time, is_deleted" +
                ") VALUES (?, ?, ?, ?, ?, NOW(), FALSE)";

        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, manager.getUsername());
            ps.setString(2, manager.getPassword());
            ps.setString(3, manager.getFullName());
            ps.setString(4, manager.getEmail());
            ps.setString(5, manager.getPhoneNo());
            return ps;
        }, keyHolder);

        // 设置自动生成的ID
        manager.setId(keyHolder.getKey().longValue());
    }

    @Override
    public void update(Manager manager) {
        String sql = "UPDATE manager SET " +
                "full_name = ?, email = ?, phone_no = ? " +
                "WHERE id = ? AND is_deleted = FALSE";

        jdbcTemplate.update(sql,
                manager.getFullName(),
                manager.getEmail(),
                manager.getPhoneNo(),
                manager.getId()
        );
    }

    // 补全接口中定义的updatePassword方法
    @Override
    public void updatePassword(Long id, String newPassword) {
        String sql = "UPDATE manager SET password = ? WHERE id = ? AND is_deleted = FALSE";
        jdbcTemplate.update(sql, newPassword, id);
    }

    @Override
    public void delete(Long id) {
        String sql = "DELETE FROM manager WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public void softDelete(Long id) {
        String sql = "UPDATE manager SET is_deleted = TRUE WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public long count() {
        String sql = "SELECT COUNT(*) FROM manager WHERE is_deleted = FALSE";
        return jdbcTemplate.queryForObject(sql, Long.class);
    }
}