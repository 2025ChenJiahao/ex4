package spittr.db;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import spittr.domain.Manager;
import java.util.List;

public interface ManagerRepository {
    // 根据ID查询
    Manager findById(Long id);

    // 根据用户名查询
    Manager findByUserName(String userName);

    // 登录验证（用户名+密码）
    Manager findByUsernameAndPassword(String username, String password);

    // 查询所有（不分页）
    List<Manager> findAll();

    // 分页查询所有（带分页参数）
    Page<Manager> findAll(Pageable pageable);

    // 新增管理员
    void save(Manager manager);

    // 更新管理员信息
    void update(Manager manager);

    // 物理删除（谨慎使用）
    void delete(Long id);

    // 软删除（逻辑删除）
    void softDelete(Long id);

    // 统计管理员总数
    long count();
    void updatePassword(Long id, String newPassword);
}