package spittr.db;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import spittr.domain.Spitter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
/**
 * 吐槽者资源库接口
 *
 * @author wben
 * @version v1.0
 */
// 注意：若使用JDBC实现，应移除JpaRepository继承（避免方法未实现）
// 如需同时支持JPA和JDBC，建议定义独立接口（如JdbcSpitterRepository单独实现非JPA接口）
public interface SpitterRepository { // 移除 extends JpaRepository<Spitter, Long>
	// 新增：支持分页的查询所有方法
	Page<Spitter> findAll(Pageable pageable);
	/**
	 * 取得吐槽者数量
	 *
	 * @return
	 */
	long count();

	/**
	 * 新建一个吐槽者
	 *
	 * @param spitter 新建的吐槽者
	 * @return 吐槽者
	 */
	Spitter save(Spitter spitter);

	/**
	 * 依据id查找吐槽者
	 *
	 * @param id 吐槽者ID
	 * @return 吐槽者
	 */
	Spitter findOne(long id);

	/**
	 * 依据用户名（登录名）查找吐槽者
	 *
	 * @param userName 用户名（登录名）
	 * @return 吐槽者
	 */
	Spitter findByUserName(String userName);

	/**
	 * 依据用户名和密码查找吐槽者
	 *
	 * @param userName 用户名
	 * @param password 密码
	 * @return 吐槽者
	 */
	Spitter findByUserNameAndPassword(String userName, String password); // 修正方法名，避免参数冲突

	/**
	 * 取得全部吐槽者
	 *
	 * @return 全部吐槽者
	 */
	List<Spitter> findAll();
}