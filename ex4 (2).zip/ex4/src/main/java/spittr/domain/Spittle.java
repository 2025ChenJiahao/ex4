package spittr.domain;

import java.sql.Timestamp;
import java.util.Date;

/**
 * 吐槽内容对象类
 * 
 * @author wben
 * @version v1.0
 */
public class Spittle {

	private Long id;
	private Spitter spitter;
	private String message;
	private Date postedTime;
	// 新增：审核相关字段
	private boolean isChecked; // 审核状态：true=已通过，false=未审核
	private Long checkerId; // 审核人ID（关联 manager.id）
	private Date checkTime; // 审核时间
	/**
	 * 构造方法
	 * 
	 * @param id
	 *            ID主键
	 * @param spitter
	 *            吐槽者
	 * @param message
	 *            内容
	 * @param postedTime
	 *            提交时间
	 */
	// 构造函数：用户发布时默认未审核
	public Spittle(Long id, Spitter spitter, String message, Date postedTime) {
		this.id = id;
		this.spitter = spitter;
		this.message = message;
		this.postedTime = postedTime;
		this.isChecked = false; // 默认未审核
	}

	public Spittle() {
		
	}


	/**
	 * 取得id主键
	 * 
	 * @return
	 */
	public Long getId() {
		return this.id;
	}

	/**
	 * 取得吐槽内容
	 * 
	 * @return
	 */
	public String getMessage() {
		return this.message;
	}

	/**
	 * 取得提交时间
	 * 
	 * @return
	 */
	public Date getPostedTime() {
		return this.postedTime;
	}

	/**
	 * 取得吐槽者
	 * 
	 * @return
	 */
	public Spitter getSpitter() {
		return this.spitter;
	}
	// 新增审核字段的 Getter/Setter
	public boolean isChecked() {
		return isChecked;
	}
	public void setChecked(boolean checked) {
		isChecked = checked;
	}

	public Long getCheckerId() {
		return checkerId;
	}

	public void setCheckerId(Long checkerId) {
		this.checkerId = checkerId;
	}

	public Date getCheckTime() {
		return checkTime;
	}

	public void setCheckTime(Date checkTime) {
		this.checkTime = checkTime;
	}

	// 各种 setter 和 getter 方法
	public void setId(Long id) {
		this.id = id;
	}

	public void setSpitter(Spitter spitter) {
		this.spitter = spitter;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setPostedTime(Timestamp postedTime) {
		this.postedTime = new Date(postedTime.getTime());
	}
}
