package spittr.web.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import spittr.db.ManagerRepository;
import spittr.domain.Manager;

import javax.servlet.http.HttpSession;
import java.util.Objects;

/**
 * 管理员核心控制器：负责登录、仪表盘、管理员CRUD、个人资料/密码管理
 */
@Controller
@RequestMapping("/manager") // 统一管理员路径前缀
public class ManagerController {

    private static final int PAGE_SIZE = 10; // 分页默认每页10条
    private final ManagerRepository managerRepository;

    @Autowired
    public ManagerController(ManagerRepository managerRepository) {
        this.managerRepository = managerRepository;
    }

    // -------------------------- 登录/退出 --------------------------
    /**
     * 显示登录页
     */
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String showLoginForm(@RequestParam(required = false) String logout, Model model) {
        if (logout != null) {
            model.addAttribute("msg", "已成功退出登录！");
        }
        return "manager/login"; // 登录页不走布局（无Session）
    }

    /**
     * 处理登录请求
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String processLogin(
            @RequestParam String username,
            @RequestParam String password,
            HttpSession session,
            Model model) {
        // 验证用户名密码（仅未删除管理员）
        Manager manager = managerRepository.findByUsernameAndPassword(username, password);
        if (manager != null) {
            session.setAttribute("loginManager", manager); // 存储登录状态
            return "redirect:/manager/dashboard"; // 登录成功→仪表盘
        } else {
            model.addAttribute("error", "用户名或密码错误，请重试！");
            model.addAttribute("username", username); // 回显用户名
            return "manager/login";
        }
    }

    /**
     * 退出登录
     */
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpSession session) {
        session.removeAttribute("loginManager"); // 清除登录状态
        session.invalidate(); // 销毁Session
        return "redirect:/manager/login?logout=success";
    }

    // -------------------------- 仪表盘 --------------------------
    /**
     * 管理员仪表盘（首页）
     */
    @RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    public String showDashboard(HttpSession session, Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        // 传递页面数据
        model.addAttribute("pageTitle", "管理员仪表盘");
        model.addAttribute("currentMenu", "dashboard");
        model.addAttribute("contentPage", "content/dashboardContent.jsp");
        model.addAttribute("loginManager", loginManager);
        return "manager/managerLayout"; // 走统一布局
    }

    // -------------------------- 管理员列表（分页） --------------------------
    @RequestMapping(value = "/managers", method = RequestMethod.GET)
    public String listManagers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(required = false) String error,
            HttpSession session,
            Model model) {
        // 处理负页码
        if (page < 0) page = 0;

        // 分页查询
        Pageable pageable = new PageRequest(page, PAGE_SIZE);
        Page<Manager> managersPage = managerRepository.findAll(pageable);

        // 传递数据
        model.addAttribute("managers", managersPage.getContent());
        model.addAttribute("totalPages", Math.max(managersPage.getTotalPages(), 0)); // 避免负页数
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "管理员管理");
        model.addAttribute("currentMenu", "managers");
        model.addAttribute("contentPage", "content/managerListContent.jsp");

        // 错误提示
        if (error != null) {
            switch (error) {
                case "cannotDeleteSelf":
                    model.addAttribute("error", "无法删除当前登录的管理员！");
                    break;
                case "invalidOperation":
                    model.addAttribute("error", "非法操作，仅允许修改自己的信息！");
                    break;
                case "managerNotFound":
                    model.addAttribute("error", "管理员不存在或已删除！");
                    break;
            }
        }

        return "manager/managerLayout";
    }

    // -------------------------- 新增管理员 --------------------------
    /**
     * 显示新增表单
     */
    @RequestMapping(value = "/managers/new", method = RequestMethod.GET)
    public String showAddForm(HttpSession session, Model model) {
        model.addAttribute("manager", new Manager());
        model.addAttribute("pageTitle", "新增管理员");
        model.addAttribute("currentMenu", "managers");
        model.addAttribute("contentPage", "content/addManagerContent.jsp");
        return "manager/managerLayout";
    }

    /**
     * 处理新增请求
     */
    @RequestMapping(value = "/managers", method = RequestMethod.POST)
    public String addManager(@ModelAttribute Manager manager, Model model, HttpSession session) {
        // 1. 校验必填项
        if (manager.getUsername() == null || manager.getUsername().trim().isEmpty()) {
            model.addAttribute("error", "用户名不能为空！");
            model.addAttribute("manager", manager);
            model.addAttribute("pageTitle", "新增管理员");
            model.addAttribute("currentMenu", "managers");
            model.addAttribute("contentPage", "content/addManagerContent.jsp");
            return "manager/managerLayout";
        }
        if (manager.getPassword() == null || manager.getPassword().trim().isEmpty()) {
            model.addAttribute("error", "密码不能为空！");
            model.addAttribute("manager", manager);
            model.addAttribute("pageTitle", "新增管理员");
            model.addAttribute("currentMenu", "managers");
            model.addAttribute("contentPage", "content/addManagerContent.jsp");
            return "manager/managerLayout";
        }

        // 2. 校验用户名唯一性
        if (managerRepository.findByUserName(manager.getUsername()) != null) {
            model.addAttribute("error", "用户名已存在，请更换！");
            model.addAttribute("manager", manager);
            model.addAttribute("pageTitle", "新增管理员");
            model.addAttribute("currentMenu", "managers");
            model.addAttribute("contentPage", "content/addManagerContent.jsp");
            return "manager/managerLayout";
        }

        // 3. 保存管理员
        managerRepository.save(manager);

        // 4. 新增成功→列表页
        return "redirect:/manager/managers";
    }

    // -------------------------- 编辑管理员 --------------------------
    /**
     * 显示编辑表单（支持个人资料/编辑他人）
     */
    @RequestMapping(value = "/managers/{id}/edit", method = RequestMethod.GET)
    public String showEditForm(
            @PathVariable Long id,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        Manager managerToEdit = managerRepository.findById(id);

        // 校验管理员存在性
        if (managerToEdit == null) {
            return "redirect:/manager/managers?error=managerNotFound";
        }

        // 传递数据
        model.addAttribute("manager", managerToEdit);
        model.addAttribute("pageTitle", "编辑管理员");
        model.addAttribute("currentMenu", "managers");
        model.addAttribute("contentPage", "content/editManagerContent.jsp");
        return "manager/managerLayout";
    }

    /**
     * 处理编辑请求
     */
    @RequestMapping(value = "/managers/{id}/update", method = RequestMethod.POST)
    public String updateManager(
            @PathVariable Long id,
            @ModelAttribute Manager manager,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        Manager existingManager = managerRepository.findById(id);

        // 1. 校验权限（仅允许编辑自己）
        if (!Objects.equals(loginManager.getId(), id) || existingManager == null) {
            return "redirect:/manager/managers?error=invalidOperation";
        }

        // 2. 保留原密码/创建时间/删除状态（不允许修改）
        manager.setPassword(existingManager.getPassword());
        manager.setCreateTime(existingManager.getCreateTime());
        manager.setDeleted(existingManager.isDeleted());

        // 3. 执行更新
        managerRepository.update(manager);

        // 4. 更新Session（避免旧数据）
        session.setAttribute("loginManager", managerRepository.findById(id));

        // 5. 更新成功→列表页
        return "redirect:/manager/managers";
    }

    // -------------------------- 个人资料（快捷入口） --------------------------
    @RequestMapping(value = "/profile", method = RequestMethod.GET)
    public String showProfile(HttpSession session, Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        // 直接跳转到当前登录管理员的编辑页
        return showEditForm(loginManager.getId(), session, model);
    }

    // -------------------------- 软删除管理员 --------------------------
    @RequestMapping(value = "/managers/{id}/delete", method = RequestMethod.GET)
    public String softDeleteManager(
            @PathVariable Long id,
            HttpSession session) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        Manager managerToDelete = managerRepository.findById(id);

        // 1. 校验权限（不能删除自己）
        if (Objects.equals(loginManager.getId(), id)) {
            return "redirect:/manager/managers?error=cannotDeleteSelf";
        }

        // 2. 校验管理员存在性
        if (managerToDelete == null) {
            return "redirect:/manager/managers?error=managerNotFound";
        }

        // 3. 执行软删除
        managerRepository.softDelete(id);

        // 4. 删除成功→列表页
        return "redirect:/manager/managers";
    }

    // -------------------------- 修改密码 --------------------------
    /**
     * 显示改密表单
     */
    @RequestMapping(value = "/changePassword", method = RequestMethod.GET)
    public String showChangePasswordForm(HttpSession session, Model model) {
        model.addAttribute("pageTitle", "修改密码");
        model.addAttribute("currentMenu", "profile");
        model.addAttribute("contentPage", "content/changePasswordContent.jsp");
        return "manager/managerLayout";
    }

    /**
     * 处理改密请求
     */
    @RequestMapping(value = "/changePassword", method = RequestMethod.POST)
    public String changePassword(
            @RequestParam String oldPassword,
            @RequestParam String newPassword,
            @RequestParam String confirmPassword,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        Manager manager = managerRepository.findById(loginManager.getId());

        // 1. 校验旧密码
        if (!Objects.equals(manager.getPassword(), oldPassword)) {
            model.addAttribute("error", "旧密码不正确！");
            model.addAttribute("pageTitle", "修改密码");
            model.addAttribute("currentMenu", "profile");
            model.addAttribute("contentPage", "content/changePasswordContent.jsp");
            return "manager/managerLayout";
        }

        // 2. 校验新密码
        if (newPassword.length() < 6) {
            model.addAttribute("error", "新密码长度不能少于6位！");
            model.addAttribute("pageTitle", "修改密码");
            model.addAttribute("currentMenu", "profile");
            model.addAttribute("contentPage", "content/changePasswordContent.jsp");
            return "manager/managerLayout";
        }
        if (!Objects.equals(newPassword, confirmPassword)) {
            model.addAttribute("error", "两次输入的新密码不一致！");
            model.addAttribute("pageTitle", "修改密码");
            model.addAttribute("currentMenu", "profile");
            model.addAttribute("contentPage", "content/changePasswordContent.jsp");
            return "manager/managerLayout";
        }

        // 3. 执行密码更新
        managerRepository.updatePassword(manager.getId(), newPassword);

        // 4. 更新Session
        session.setAttribute("loginManager", managerRepository.findById(manager.getId()));

        // 5. 改密成功→仪表盘
        model.addAttribute("success", "密码修改成功！");
        return showDashboard(session, model);
    }
}