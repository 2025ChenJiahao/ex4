package spittr.web.manager;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 管理员拦截器，确保只有登录的管理员才能访问管理员功能
 */
public class ManagerInterceptor implements HandlerInterceptor {

    /**
     * 在请求处理之前进行调用
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        // 获取请求的URL
        String requestURI = request.getRequestURI();

        // 登录页面和登录请求不拦截
        if (requestURI.contains("/manager/login")) {
            return true;
        }

        // 检查session中是否有登录的管理员
        HttpSession session = request.getSession();
        Object loginManager = session.getAttribute("loginManager");

        if (loginManager != null) {
            // 已登录，放行
            return true;
        } else {
            // 未登录，重定向到登录页面
            response.sendRedirect(request.getContextPath() + "/manager/login");
            return false;
        }
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
