package spittr.web.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import spittr.db.SpitterRepository;
import spittr.domain.Manager;
import spittr.domain.Spitter;

import javax.servlet.http.HttpSession;
import java.util.Date;

/**
 * 普通用户管理控制器
 */
@Controller
@RequestMapping("/manager/spitters")
public class SpitterManagerController {

    private final SpitterRepository spitterRepository;
    private static final int PAGE_SIZE = 10;

    @Autowired
    public SpitterManagerController(SpitterRepository spitterRepository) {
        this.spitterRepository = spitterRepository;
    }

    /**
     * 分页查询普通用户列表
     */
    @RequestMapping(method = RequestMethod.GET)
    public String listSpitters(
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        if (page < 0) page = 0;

        // 分页查询
        Pageable pageable = new PageRequest(page, PAGE_SIZE);
        Page<Spitter> spittersPage = spitterRepository.findAll(pageable);

        // 传递数据
        model.addAttribute("spitters", spittersPage.getContent());
        model.addAttribute("totalPages", Math.max(spittersPage.getTotalPages(), 0));
        model.addAttribute("currentPage", page);
        model.addAttribute("pageTitle", "普通用户管理");
        model.addAttribute("currentMenu", "spitters");
        // 修改返回的内容页为新的 spitterListContent.jsp
        model.addAttribute("contentPage", "content/spitterListContent.jsp");
        model.addAttribute("loginManager", loginManager);

        // 新增：传递当前时间作为默认值
        model.addAttribute("currentTime", new Date());

        return "manager/managerLayout";
    }
}