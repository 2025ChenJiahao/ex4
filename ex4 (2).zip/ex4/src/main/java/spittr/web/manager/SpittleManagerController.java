package spittr.web.manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import spittr.db.SpittleRepository;
import spittr.domain.Manager;
import spittr.domain.Spittle;

import javax.servlet.http.HttpSession;

/**
 * 吐槽管理控制器（含审核功能）
 */
@Controller
@RequestMapping("/manager/spittles")
public class SpittleManagerController {

    private static final int PAGE_SIZE = 10;
    private final SpittleRepository spittleRepository;

    @Autowired
    public SpittleManagerController(SpittleRepository spittleRepository) {
        this.spittleRepository = spittleRepository;
    }

    // -------------------------- 所有吐槽（分页） --------------------------
    @RequestMapping(method = RequestMethod.GET)
    public String listAllSpittles(
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        if (page < 0) page = 0;

        Pageable pageable = new PageRequest(page, PAGE_SIZE);
        Page<Spittle> spittles = spittleRepository.findAll(pageable);

        // 传递数据
        model.addAttribute("spittles", spittles.getContent());
        model.addAttribute("totalPages", Math.max(spittles.getTotalPages(), 0));
        model.addAttribute("currentPage", page);
        model.addAttribute("activeTab", "all");
        model.addAttribute("pageTitle", "吐槽管理");
        model.addAttribute("currentMenu", "spittles");
        model.addAttribute("contentPage", "content/spittleListContent.jsp");
        model.addAttribute("loginManager", loginManager);

        return "manager/managerLayout";
    }

    // -------------------------- 未审核吐槽（分页） --------------------------
    @RequestMapping(value = "/unchecked", method = RequestMethod.GET)
    public String listUncheckedSpittles(
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        if (page < 0) page = 0;

        Pageable pageable = new PageRequest(page, PAGE_SIZE);
        Page<Spittle> spittles = spittleRepository.findByCheckedFalse(pageable);

        // 传递数据
        model.addAttribute("spittles", spittles.getContent());
        model.addAttribute("totalPages", Math.max(spittles.getTotalPages(), 0));
        model.addAttribute("currentPage", page);
        model.addAttribute("activeTab", "unchecked");
        model.addAttribute("pageTitle", "未审核吐槽管理");
        model.addAttribute("currentMenu", "spittles");
        model.addAttribute("contentPage", "content/spittleListContent.jsp");
        model.addAttribute("loginManager", loginManager);

        return "manager/managerLayout";
    }

    // -------------------------- 审核通过吐槽 --------------------------
    @RequestMapping(value = "/{id}/approve", method = RequestMethod.GET)
    public String approveSpittle(
            @PathVariable Long id,
            HttpSession session) {
        Manager loginManager = (Manager) session.getAttribute("loginManager");
        // 两种审核方式：1. 更新状态 2. 记录审核人（推荐第二种）
        spittleRepository.checkSpittle(id, loginManager.getId()); // 记录审核人+时间
        return "redirect:/manager/spittles/unchecked"; // 审核后返回未审核列表
    }

    // -------------------------- 删除吐槽 --------------------------
    @RequestMapping(value = "/{id}/delete", method = RequestMethod.GET)
    public String deleteSpittle(@PathVariable Long id) {
        spittleRepository.delete(id);
        return "redirect:/manager/spittles"; // 删除后返回所有吐槽列表
    }
}