package spittr.web;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import spittr.web.manager.ManagerInterceptor;

/**
 * webMVC配置
 *
 * @author wben
 * @version v1.0
 */
@Configuration
@EnableWebMvc
@ComponentScan("spittr.web") // 扫描所有web层Controller
public class WebConfig extends WebMvcConfigurerAdapter {

	/**
	 * 自定义视图解析器（JSP路径：/WEB-INF/views/xxx.jsp）
	 */
	@Bean
	public ViewResolver viewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}

	/**
	 * 启用默认Servlet处理静态资源（如CSS、JS）
	 */
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}

	/**
	 * 配置静态资源映射（/resources/** 对应 webapp/resources/ 目录）
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
		super.addResourceHandlers(registry);
	}

	/**
	 * 注册管理员拦截器：拦截所有/manager/**请求，排除登录页
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new ManagerInterceptor())
				.addPathPatterns("/manager/**") // 拦截管理员所有路径
				.excludePathPatterns("/manager/login"); // 排除登录页
		super.addInterceptors(registry);
	}

	/**
	 * 注册管理员拦截器Bean（确保Spring管理）
	 */
	@Bean
	public ManagerInterceptor managerInterceptor() {
		return new ManagerInterceptor();
	}
}