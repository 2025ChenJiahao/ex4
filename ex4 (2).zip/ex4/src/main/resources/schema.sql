-- 创建 Spitter 表（避免重复创建）
CREATE TABLE IF NOT EXISTS Spitter (
                                       id identity,
                                       username varchar(20) unique not null,
                                       password varchar(20) not null,
                                       first_name varchar(30) not null,
                                       last_name varchar(30) not null,
                                       email varchar(30) not null
);

-- 重建 spittle 表（含审核字段，避免重复创建用 IF NOT EXISTS）
CREATE TABLE IF NOT EXISTS spittle (
                                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                       spitter BIGINT NOT NULL, -- 关联 Spitter 表的用户ID
                                       message VARCHAR(2000) NOT NULL, -- 发言内容
                                       postedTime DATETIME NOT NULL, -- 发布时间
                                       is_checked BOOLEAN DEFAULT FALSE, -- 审核状态：默认未审核（false）
                                       checker_id BIGINT, -- 审核人ID（关联 manager 表的 id）
                                       check_time TIMESTAMP, -- 审核时间
                                       FOREIGN KEY (spitter) REFERENCES Spitter(id) -- 外键关联
);


-- 第 1 条：添加 is_checked 列
ALTER TABLE spittle
    ADD COLUMN IF NOT EXISTS is_checked BOOLEAN DEFAULT FALSE;

-- 第 2 条：添加 checker_id 列
ALTER TABLE spittle
    ADD COLUMN IF NOT EXISTS checker_id BIGINT;

-- 第 3 条：添加 check_time 列
ALTER TABLE spittle
    ADD COLUMN IF NOT EXISTS check_time TIMESTAMP;




-- 新增 Manager 表
-- 1. 管理员表（列名：username，无下划线）
CREATE TABLE IF NOT EXISTS manager (
                                       id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                       username VARCHAR(50) NOT NULL UNIQUE COMMENT '管理员账号（列名无下划线）',
                                       password VARCHAR(100) NOT NULL COMMENT '密码（示例用明文，实际项目需加密）',
                                       full_name VARCHAR(100) COMMENT '姓名',
                                       email VARCHAR(100) COMMENT '邮箱',
                                       phone_no VARCHAR(20) COMMENT '手机号',
                                       create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                       is_deleted BOOLEAN DEFAULT FALSE COMMENT '软删除标记（true=已删除）'
);

-- 2. 初始化默认管理员（列名：username，与表结构一致）
INSERT INTO manager (username, password, full_name, email, phone_no)
SELECT
    'admin',                -- 管理员账号
    'admin123',             -- 密码（测试用，实际需加密）
    '系统管理员',           -- 姓名
    'admin@example.com',    -- 邮箱
    '13800138000'           -- 手机号
WHERE NOT EXISTS (SELECT 1 FROM manager WHERE username = 'admin'); -- 避免重复插入