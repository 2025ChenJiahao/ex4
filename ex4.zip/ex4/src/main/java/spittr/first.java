package spittr;

public class first {
}
